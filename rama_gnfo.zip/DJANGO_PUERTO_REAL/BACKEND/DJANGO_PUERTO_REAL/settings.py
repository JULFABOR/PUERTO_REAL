"""
Configuración de Django para el proyecto DJANGO_PUERTO_REAL.

Generado por 'django-admin startproject' usando Django 5.2.1.

Para más información sobre este archivo, consulta:
https://docs.djangoproject.com/en/5.2/topics/settings/

Para la lista completa de configuraciones y sus valores, consulta:
https://docs.djangoproject.com/en/5.2/ref/settings/
"""

from pathlib import Path
import os
from dotenv import load_dotenv
import sys

# Construye rutas dentro del proyecto así: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent
    
if str(BASE_DIR.parent) not in sys.path:
    sys.path.insert(0, str(BASE_DIR.parent))

load_dotenv(os.path.join(BASE_DIR, '.env'))

# Configuración de desarrollo de inicio rápido - no apta para producción
# Consulta https://docs.djangoproject.com/en/5.2/howto/deployment/checklist/

# ADVERTENCIA DE SEGURIDAD: ¡mantén en secreto la clave secreta utilizada en producción!
SECRET_KEY = os.getenv('SECRET_KEY')

# ADVERTENCIA DE SEGURIDAD: ¡no ejecutes con el modo depuración activado en producción!
DEBUG = True

ALLOWED_HOSTS = []


# Definición de la aplicación

INSTALLED_APPS = [
    'jazzmin', 
    'django.contrib.admin',  
    'django.contrib.auth',  
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles', 
    'rest_framework', # Para construir APIs RESTful
    'django_filters', # Para filtrado avanzado
    'rest_framework.authtoken', # Para autenticación por token
    'corsheaders', # Para manejar CORS 
    'HOME', # Aplicación principal
    'autenticacion', 
    'Auditoria', 
    # --- INICIO: Bloque comentado para depuración ---
    # 'Abrir_Cerrar_CAJA', 
    # 'Control_COMPRAS', 
    # 'Control_VENTAS',
    # 'Control_STOCK',
    # 'Fidelizar_CLIENTES',  
    # 'Analizar_INGRESOS_EGRESOS', 
    # --- FIN: Bloque comentado para depuración ---
]

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [ 
        'rest_framework.authentication.TokenAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ]
}

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'DJANGO_PUERTO_REAL.urls'


WSGI_APPLICATION = 'DJANGO_PUERTO_REAL.wsgi.application'


TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]


# Base de datos
# https://docs.djangoproject.com/en/5.2/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': os.getenv('DB_NAME'),
        'USER': os.getenv('DB_USER'),
        'PASSWORD': os.getenv('DB_PASSWORD'),
        'HOST': os.getenv('DB_HOST'),
        'PORT': os.getenv('DB_PORT'),
    }
}


# Validación de contraseña
# https://docs.djangoproject.com/en/5.2/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Configuración de Email para producción (usando Gmail)
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = os.getenv('EMAIL_HOST_USER')
EMAIL_HOST_PASSWORD = os.getenv('EMAIL_HOST_PASSWORD')
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER

# Internacionalización
# https://docs.djangoproject.com/en/5.2/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True


# Archivos estáticos (CSS, JavaScript, Imágenes)
# https://docs.djangoproject.com/en/5.2/howto/static-files/

STATIC_URL = 'static/'

STATICFILES_DIRS = [
    os.path.join(BASE_DIR.parent.parent, 'FRONTEND', 'dist', 'assets')
]
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')


# Tipo de campo de clave primaria predeterminado
# https://docs.djangoproject.com/en/5.2/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Configuraciones personalizadas
PESOS_POR_PUNTO = 110

# Redirecciones de Login/Logout
LOGIN_REDIRECT_URL = 'home:index_privado_staff'
LOGOUT_REDIRECT_URL = 'home:index_publico'

# Configuración de CORS
# Define qué orígenes de frontend tienen permitido acceder a esta API.
# En producción, esto debería ser la URL de tu frontend, p. ej., 'https://yourfrontend.com'
FRONTEND_URL = os.getenv('FRONTEND_URL', 'http://localhost:5173')
CORS_ALLOWED_ORIGINS = os.getenv(
    'DJANGO_CORS_ALLOWED_ORIGINS',
    'http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000'
).split(',')

# Si necesitas permitir credenciales (cookies, encabezados de autenticación) desde el frontend.
# CORS_ALLOW_CREDENTIALS = True

# Orígenes de confianza para CSRF, importante para POST, PUT, DELETE requests.
CSRF_TRUSTED_ORIGINS = os.getenv(
    'DJANGO_CSRF_TRUSTED_ORIGINS',
    'http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000'
).split(',')

JAZZMIN_SETTINGS = {
    # Título de la ventana (se verá en la pestaña del navegador)
    "site_title": "Puerto Real Admin",

    # Título en la pantalla de login
    "site_header": "Puerto Real",

    # Título en la barra de navegación
    "site_brand": "Puerto Real",

    # Texto de bienvenida en la esquina superior derecha
    "welcome_sign": "Bienvenido a Puerto Real",

    # Copyright en el pie de página
    "copyright": "Puerto Real Ltd.",

    # Tema
    # Puedes encontrar más temas en la documentación de Jazzmin
    "theme": "darkly",
    
}
